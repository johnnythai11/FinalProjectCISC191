package controller;

public class HowToPlayScreenController
{

	public HowToPlayScreenController()
	{
		// TODO Auto-generated constructor stub
	}

}
